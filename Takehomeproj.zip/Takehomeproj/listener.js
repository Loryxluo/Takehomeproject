//var HashMap= require('hashmap');
var word_map = new Map([
    ['B','busy'],
    ['K','KTV'],
    ['BK','bugerking'],
    ['Z','zoo'],
    ['R','run'],
    ['KL','kelly'],
    ['B-B-K','best'],
    ['LL','lucky lucy'],
    ['B--B-K---Z', 'food'],
    ['BBKZ', 'vomit'],
    ['B-K-RKK---ZZZ', 'sleep'],
    ['BKR-KK-ZZZ', 'philosophy'],
    ['ZZ-KK', 'need'],
    ['KK-ZZ', 'hate'],
    ['L-R-Z', 'I'],
    ['Z-R-L', 'you'],
    ['ZZKK', 'rejoice'],
  ]);
 
 
const { io } = require("socket.io-client");
const socket = io("http://localhost:3000");
const syllables = ['B', 'K', 'L', 'R', 'Z'];
socket.on('connect',()=>{
        console.log('Listener Connect');
});
//var strStr = function(haystack, needle) {
    //return needle==""?0:haystack.indexOf(needle);
//};

//function to reverse the receing message
const reverse_word =str=>{
  var returnStr="";
  for(var i=str.length-1;i>=0;i--){
      returnStr+= str.toString().charAt(i);
  }
  return returnStr;
}

var sents ="";
var singlesents="";

//for testing the transaltion
//var broadcastmsg="B-B-K-----K----------L-----BBKZ---------Z---------BKZ"
 //----------Z---------ZKBB-----L ->L-----BBKZ---------Z
//Z ----ZKBB L
 syllables.forEach((broadcastmsg) => {
    //socket.on(broadcastmsg, (...args) => {
      socket.on('message',(broadcastmsg)=>{
        if(broadcastmsg !=null){
       console.log("received "+broadcastmsg +" at " + new Date().getTime());      
        //var i=strStr(broadcastmsg,"----");  
        var reversemsg=reverse_word(broadcastmsg);
        //console.log(reversemsg);
      var str=reversemsg.split("----------");
//console.log(str[0]);
//console.log(str[1]);
for(var i=0 ;i<reversemsg.length;i++){
  if(str[i]==null){  //true   
          singlesents=str[i+1];   //singlesents=Z---------ZKBB-----L
      }
  else{
          singlesents=str[i];
      }
      if(singlesents)
      {
          var wordStr = (singlesents).split('-----');  //Z  //----ZKBB
      for(var j=0;j<wordStr.length;j++)  
      {    
          if(word_map.get(reverse_word(wordStr[j]))!=null){  
          var word=word_map.get(reverse_word(wordStr[j])); //zoo   
          console.log(reverse_word(wordStr[j])+" means "+word) //Z means zoo
          sents +=word+" ";
        }
     else{
      //console.log(reverse_word(wordStr[j])+" is Unrecogized");
       sents+="Unrecogized ";
       } 
      }   
      }
  }   
sents = sents.split(' ').reverse().join(' ');
console.log(sents+'\n');
        }
        
    });
   });