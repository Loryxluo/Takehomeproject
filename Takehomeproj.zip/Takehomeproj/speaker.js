//speaker-server side
const express = require('express');
const app = express();
const http = require('http');
const server = http.createServer(app);
const { Server } = require('socket.io');
const io = new Server(server);
var count=0;

//function for generate a message by words
//For receivng the limited length of each sentense
//genenrating a message
const number=process.argv[2];
const generateWords = size => {
  var msg="";
  const syllables = ['B', 'K', 'L', 'R', 'Z','-'];
  var s= syllables[Math.floor(Math.random() * syllables.length)];
  if(s!='-'){
      msg+=s;
  for(var i=0;i<size-1;i++){
     msg+= syllables[Math.floor(Math.random() * syllables.length)];    
      }
      return msg;
  }
  
}

//const io = require('socket.io')(server);
//for 1/2 choice to emit either a real message or a pure slience
const emitMessage =()=>{
  var randonNum= Math.round(Math.random ());
  if(randonNum!=1){
    var broadcastmsg=generateWords(number);  
     //console.log('Emitting',broadcastmsg); 
     //for testing io.sockets.emit('message',broadcastmsg,'add to test');
      io.sockets.emit('message',broadcastmsg); 
  }
  else{
    //console.log('Emitting nothing'); 
    io.sockets.emit('message',{}); 
  }
}

//count the current connected listener
//socket.emit sending to only current socket listener
//sockets.emit for all lisenters,include speaker
//socket.broadcast.emit all clients except sender
//sockets.socket(socketid).emit for individual
io.sockets.on('connection', (socket) => {
    count++;
  console.log('Listener connected '+ count + ' listener(s) present');
  socket.emit('listeners',{number:count});
  socket.broadcast.emit('listeners',{number:count});
  if(count>=1){ //if have one user connect start to send message
    setInterval(()=>{emitMessage()},200);
  }
  socket.on('disconnect', () => { 
    count--;
    console.log(count + ' Listener still connect'); 
    socket.broadcast.emit('listeners',{number:count});
    if(count==0){ //if connected client become 0 stop send message
      console.log('No Listener disconnected');
      console.log('Stop Broadcast beyond time');
      clearTimeout(timeoutObj);
      clearImmediate(immediateObj);
      clearInterval(intervalObj);
    }
  });
});

server.listen(3000, () => { console.log('listening on *:3000'); });

const timeoutObj=setTimeout(() => {
  console.log('timeout beyond time');
}, 15000);

const immediateObj = setImmediate(() => {
  console.log('immediately executing immediate');
});

const intervalObj = setInterval(()=>emitMessage(),200);

//setInterval( emitMessage(),timer);


/*setInterval( 
  () => {
    const s = syllables[Math.floor(Math.random() * syllables.length)];//random pick a syllables in the string
    //var s = "BBKZ";
    console.log('Emitting ', s); 
    if (s != '-') {       
       msg+=s;
      io.sockets.emit(s);  
   }
  },
  200);*/
 